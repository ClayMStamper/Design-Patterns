//the interface for creating all of our victims

public interface VictimPlan {
  public void SetHead (string head);
  public void SetTorso (string torso);
  public void SetArms (string arms);
  public void SetLegs (string legs);
}
